package main

import (
	"fmt"
	"sort"
	"strings"
)

func main() {
	// Input data sesuai format tabel
	input := [][]int{
		{3},
		{5, 2, 1, 7, 9, 13},
		{6, 189, 15, 27, 39, 75, 133},
		{3, 4, 9, 1},
	}

	// Proses untuk setiap daerah
	for _, nums := range input {
		oddNumbers := []int{}
		evenNumbers := []int{}

		// Pisahkan bilangan ganjil dan genap
		for _, num := range nums {
			if num%2 == 0 {
				evenNumbers = append(evenNumbers, num)
			} else {
				oddNumbers = append(oddNumbers, num)
			}
		}

		// Urutkan ganjil dari besar ke kecil
		sort.Sort(sort.Reverse(sort.IntSlice(oddNumbers)))

		// Urutkan genap dari kecil ke besar
		sort.Ints(evenNumbers)

		// Gabungkan hasilnya
		output := append(oddNumbers, evenNumbers...)

		// Cetak hasil dalam satu baris
		outputStr := strings.Trim(strings.Replace(fmt.Sprint(output), " ", " ", -1), "[]")
		fmt.Println(outputStr)
	}
}
