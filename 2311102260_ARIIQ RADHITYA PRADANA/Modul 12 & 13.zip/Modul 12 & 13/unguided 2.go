package main

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
)

// Fungsi untuk menghitung median dari data yang telah diurutkan
func calculateMedian(data []int) int {
	n := len(data)
	if n%2 == 0 {
		return (data[n/2-1] + data[n/2]) / 2
	}
	return data[n/2]
}

func main() {
	reader := bufio.NewReader(os.Stdin)

	fmt.Println("Masukkan deretan angka, pisahkan dengan spasi. Akhiri dengan -5313:")

	// Membaca input dari pengguna
	input, _ := reader.ReadString('\n')
	input = strings.TrimSpace(input)

	// Memisahkan input menjadi angka
	inputs := strings.Split(input, " ")

	var data []int

	for _, item := range inputs {
		num, err := strconv.Atoi(item)
		if err != nil {
			fmt.Println("Input tidak valid:", item)
			return
		}

		// Jika input adalah -5313, hentikan program
		if num == -5313 {
			break
		}

		// Jika input adalah 0, hitung median
		if num == 0 {
			if len(data) > 0 {
				sort.Ints(data) // Urutkan data
				median := calculateMedian(data)
				fmt.Println(median)
			}
		} else {
			// Tambahkan angka ke dalam data
			data = append(data, num)
		}
	}
}
