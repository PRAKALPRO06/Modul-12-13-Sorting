package main

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
)

// Konstanta dan tipe data
const nMax = 7919

type Buku struct {
	id, judul, penulis, penerbit string
	eksemplar, tahun, rating     int
}

type DaftarBuku []Buku

// Fungsi untuk membaca input dari pengguna
func bacaInput() string {
	reader := bufio.NewReader(os.Stdin)
	input, _ := reader.ReadString('\n')
	return strings.TrimSpace(input)
}

// Input data buku ke pustaka
func DaftarkanBuku(pustaka *DaftarBuku, n int) {
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data buku ke-%d (format: id judul penulis penerbit eksemplar tahun rating):\n", i+1)
		data := bacaInput()
		fields := strings.Fields(data)
		if len(fields) < 7 {
			fmt.Println("Data tidak lengkap. Ulangi!")
			i--
			continue
		}

		eksemplar, _ := strconv.Atoi(fields[4])
		tahun, _ := strconv.Atoi(fields[5])
		rating, _ := strconv.Atoi(fields[6])

		buku := Buku{
			id:        fields[0],
			judul:     fields[1],
			penulis:   fields[2],
			penerbit:  fields[3],
			eksemplar: eksemplar,
			tahun:     tahun,
			rating:    rating,
		}
		*pustaka = append(*pustaka, buku)
	}
}

// Menampilkan buku terfavorit
func CetakTerfavorit(pustaka DaftarBuku, n int) {
	if n == 0 {
		fmt.Println("Tidak ada buku.")
		return
	}
	maxRating := -1
	var favorit Buku
	for _, buku := range pustaka {
		if buku.rating > maxRating {
			maxRating = buku.rating
			favorit = buku
		}
	}
	fmt.Printf("Buku Terfavorit:\nJudul: %s\nPenulis: %s\nPenerbit: %s\nTahun: %d\n",
		favorit.judul, favorit.penulis, favorit.penerbit, favorit.tahun)
}

// Mengurutkan pustaka berdasarkan rating secara menurun
func UrutBuku(pustaka *DaftarBuku, n int) {
	sort.Slice(*pustaka, func(i, j int) bool {
		return (*pustaka)[i].rating > (*pustaka)[j].rating
	})
}

// Menampilkan 5 buku dengan rating tertinggi
func Cetak5Terbaru(pustaka DaftarBuku, n int) {
	fmt.Println("5 Buku dengan Rating Tertinggi:")
	for i := 0; i < n && i < 5; i++ {
		fmt.Printf("%d. %s (Rating: %d)\n", i+1, pustaka[i].judul, pustaka[i].rating)
	}
}

// Mencari buku dengan rating tertentu menggunakan pencarian biner
func CariBuku(pustaka DaftarBuku, n int, r int) {
	low, high := 0, n-1
	for low <= high {
		mid := (low + high) / 2
		if pustaka[mid].rating == r {
			buku := pustaka[mid]
			fmt.Printf("Buku Ditemukan:\nJudul: %s\nPenulis: %s\nPenerbit: %s\nTahun: %d\nEksemplar: %d\nRating: %d\n",
				buku.judul, buku.penulis, buku.penerbit, buku.tahun, buku.eksemplar, buku.rating)
			return
		} else if pustaka[mid].rating < r {
			high = mid - 1
		} else {
			low = mid + 1
		}
	}
	fmt.Println("Tidak ada buku dengan rating seperti itu.")
}

func main() {
	var n, targetRating int
	var pustaka DaftarBuku

	// Input jumlah buku
	fmt.Println("Masukkan jumlah buku:")
	n, _ = strconv.Atoi(bacaInput())

	// Daftarkan buku
	DaftarkanBuku(&pustaka, n)

	// Cetak buku terfavorit
	CetakTerfavorit(pustaka, n)

	// Urutkan pustaka berdasarkan rating
	UrutBuku(&pustaka, n)

	// Cetak 5 buku terbaru
	Cetak5Terbaru(pustaka, n)

	// Input rating yang dicari
	fmt.Println("Masukkan rating yang ingin dicari:")
	targetRating, _ = strconv.Atoi(bacaInput())

	// Cari buku berdasarkan rating
	CariBuku(pustaka, n, targetRating)
}
